// 업적 클릭 이벤트입니다. 만약을 위해 만들어 두었습니다. 업적을 클릭할 경우 업적 이미지가 변하고 업적 달성 숫자가 1 올라갑니다. 하지만 DB와 연결된 이벤트가 아니기 때문에 새로고침하면 모두 초기화됩니다. DB로 연결되는 이벤트가 잘 완성됐다면 이 문서는 필요 없으니 지워주세요.

// let achievScore = 0

// $(function () {
//   $('#achiev_content_1').one('click', function () {
//     $(this).find('img').attr('src', '/images/achieve_3_color.png')
//     $('.achiev_score').html(`${++achievScore}`)
//   })

//   $('#achiev_content_2').one('click', function () {
//     $(this).find('img').attr('src', '/images/achieve_4_color.png')
//     $('.achiev_score').html(`${++achievScore}`)
//   })

//   $('#achiev_content_3').one('click', function () {
//     $(this).find('img').attr('src', '/images/achieve_5_color.png')
//     $('.achiev_score').html(`${++achievScore}`)
//   })

//   $('#achiev_content_4').one('click', function () {
//     $(this).find('img').attr('src', '/images/achieve_6_color.png')
//     $('.achiev_score').html(`${++achievScore}`)
//   })

//   $('#achiev_content_5').one('click', function () {
//     $(this).find('img').attr('src', '/images/achieve_7_color.png')
//     $('.achiev_score').html(`${++achievScore}`)
//   })

//   $('#achiev_content_6').one('click', function () {
//     $(this).find('img').attr('src', '/images/achieve_8_color.png')
//     $('.achiev_score').html(`${++achievScore}`)
//   })

//   $('#achiev_content_7').one('click', function () {
//     $(this).find('img').attr('src', '/images/achieve_9_color.png')
//     $('.achiev_score').html(`${++achievScore}`)
//   })

//   $('#achiev_content_8').one('click', function () {
//     $(this).find('img').attr('src', '/images/achieve_10_color.png')
//     $('.achiev_score').html(`${++achievScore}`)
//   })

//   $('#achiev_content_9').one('click', function () {
//     $(this).find('img').attr('src', '/images/achieve_11_color.png')
//     $('.achiev_score').html(`${++achievScore}`)
//   })

//   $('#achiev_content_10').one('click', function () {
//     $(this).find('img').attr('src', '/images/achieve_12_color.png')
//     $('.achiev_score').html(`${++achievScore}`)
//   })

//   $('#achiev_content_11').one('click', function () {
//     $(this).find('img').attr('src', '/images/achieve_13_color.png')
//     $('.achiev_score').html(`${++achievScore}`)
//   })

//   $('#achiev_content_12').one('click', function () {
//     $(this).find('img').attr('src', '/images/achieve_14_color.png')
//     $('.achiev_score').html(`${++achievScore}`)
//   })

//   $('#achiev_content_13').one('click', function () {
//     $(this).find('img').attr('src', '/images/achieve_15_color.png')
//     $('.achiev_score').html(`${++achievScore}`)
//   })

//   $('#achiev_content_14').one('click', function () {
//     $(this).find('img').attr('src', '/images/achieve_16_color.png')
//     $('.achiev_score').html(`${++achievScore}`)
//   })
// })
