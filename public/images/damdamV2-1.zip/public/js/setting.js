let moveBtn = document.querySelectorAll(".setting-movebun");
let moveBar = document.querySelectorAll(".setting-ellipse");

let resetBtn = document.querySelectorAll(".setting-resetBtn");
let modal = document.querySelectorAll(".setting-modal");
let modalBg = document.querySelectorAll(".setting-modal-bg");
resetBtn.forEach((e, i) => {
  e.addEventListener("click", () => {
    modalBg[i].classList.add("abc");
  });
});
modalBg.forEach((e) => {
  e.addEventListener("click", () => {
    e.classList.remove("abc");
  });
});
